"""Contains Blender-specific utility functions."""
