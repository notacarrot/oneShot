"""Contains :code:`OpenGL` functions to render point clouds."""
